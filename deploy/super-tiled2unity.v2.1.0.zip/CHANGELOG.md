# Changelog

## [2.1.0] - 2023-09-13
- Feature: Tileset Image Collection Subrects are now supported
- Bug fix: Compiler warnings for Unity Version 2022.3 and newer fixed

## [2.0.1] - 2023-08-21
- Bug fix: Fixed compile errors with Unity version 2022.1 and earlier

## [2.0.0] - 2023-08-19
- Initial submission
- Super Tiled2Unity jumps to version 2.0.0 as a package managed by the UPM

