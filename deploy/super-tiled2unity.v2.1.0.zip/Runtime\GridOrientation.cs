﻿namespace SuperTiled2Unity
{
    public enum GridOrientation
    {
        Orthogonal,
        Isometric,
    }
}
