﻿using UnityEngine;

namespace SuperTiled2Unity
{
    public class SuperWorld : MonoBehaviour
    {
        [ReadOnly]
        public ImportErrors m_ImportErrors;
    }
}
