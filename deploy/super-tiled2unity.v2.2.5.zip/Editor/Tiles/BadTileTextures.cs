using UnityEngine;

// Only make one of these during development
//[CreateAssetMenu(fileName = "BadTileTextures", menuName = "Super Tiled2Unity/Create BadTileTexture files")]
public class BadTileTextures : ScriptableObject
{
    public Texture2D[] m_Textures;
}
