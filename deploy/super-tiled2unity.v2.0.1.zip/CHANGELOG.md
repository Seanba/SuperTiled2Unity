# Changelog

## [2.0.0] - 2023-01-04
- Initial submission
- Super Tiled2Unity jumps to version 2.0.0 as a package managed by the UPM