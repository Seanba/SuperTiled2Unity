﻿using System;

namespace SuperTiled2Unity.Editor
{
    class TiledException : Exception
    {
    }
}
