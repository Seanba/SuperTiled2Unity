﻿#if !UNITY_2020_3_OR_NEWER
#error Super Tiled2Unity requires Unity 2020.3 or newer
#endif