﻿namespace SuperTiled2Unity
{
    public class SuperTileLayer : SuperLayer
    {
    }
}
