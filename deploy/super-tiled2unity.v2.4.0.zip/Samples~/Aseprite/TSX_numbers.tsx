<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.11" tiledversion="1.11.2" name="TSX_numbers" tilewidth="64" tileheight="64" tilecount="9" columns="3">
 <image source="ASE_numbers.aseprite" width="192" height="192"/>
</tileset>
