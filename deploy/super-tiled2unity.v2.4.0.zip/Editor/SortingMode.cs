﻿namespace SuperTiled2Unity.Editor
{
    public enum SortingMode
    {
        Stacked = 0,
        CustomSortAxis,
    }
}
