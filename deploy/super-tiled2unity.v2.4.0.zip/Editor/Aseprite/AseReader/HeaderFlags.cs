﻿using System;

namespace SuperTiled2Unity.Ase.Editor
{
    [Flags]
    public enum HeaderFlags : uint
    {
        HasLayerOpacity = 1,
    }
}
