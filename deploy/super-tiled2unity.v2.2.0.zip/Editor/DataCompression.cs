﻿namespace SuperTiled2Unity.Editor
{
    public enum DataCompression
    {
        None,
        Gzip,
        Zlib,
        Zstd,
    }
}
