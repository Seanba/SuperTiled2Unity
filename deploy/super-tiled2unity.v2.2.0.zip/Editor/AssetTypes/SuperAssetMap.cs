﻿namespace SuperTiled2Unity.Editor
{
    public class SuperAssetMap : SuperAsset
    {
    }
}
