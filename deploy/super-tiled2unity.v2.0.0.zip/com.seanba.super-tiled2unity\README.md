# Readme

fixit - my todo list
- I think this readme should be removed. some Other packages don't have them.
- Figure out how to handle internal versioning (only want it set in package.json file)

