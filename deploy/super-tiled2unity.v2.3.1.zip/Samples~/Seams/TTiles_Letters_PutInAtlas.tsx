<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.11" tiledversion="1.11.2" name="Light_Letters (In Atlas)" tilewidth="8" tileheight="8" spacing="1" margin="1" tilecount="55" columns="11">
 <image source="T_Letters.png" width="100" height="46"/>
</tileset>
